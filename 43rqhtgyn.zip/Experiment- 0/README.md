## HTML + CSS + JavaScript

This is a sample project to demonstrate the use of HTML, CSS and JavaScript. Start modefy the index.html, styles.css & script.js files to see the changes.

## How to run

1. Run the follwing command in your terminal:
```bash
live-server --no-browser
```

2. Refresh the URL in simple browser to see the output